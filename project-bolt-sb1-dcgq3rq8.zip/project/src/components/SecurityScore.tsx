import React from 'react';
import { Shield, TrendingUp, Award, AlertCircle } from 'lucide-react';

interface SecurityScoreProps {
  passwordScore: number;
  twoFactorEnabled: number;
  browserSecurityScore: number;
  emailBreached: boolean;
}

export function SecurityScore({ 
  passwordScore, 
  twoFactorEnabled, 
  browserSecurityScore, 
  emailBreached 
}: SecurityScoreProps) {
  // Calculate overall security score
  const passwordWeight = 0.3;
  const twoFactorWeight = 0.3;
  const browserWeight = 0.3;
  const breachPenalty = 0.1;

  let overallScore = 
    passwordScore * passwordWeight +
    (twoFactorEnabled / 6) * 100 * twoFactorWeight +
    browserSecurityScore * browserWeight;

  if (emailBreached) {
    overallScore -= breachPenalty * 100;
  }

  overallScore = Math.max(0, Math.min(100, Math.round(overallScore)));

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Very Good';
    if (score >= 70) return 'Good';
    if (score >= 60) return 'Fair';
    if (score >= 40) return 'Poor';
    return 'Very Poor';
  };

  const getRecommendations = () => {
    const recommendations = [];
    
    if (passwordScore < 70) {
      recommendations.push('Improve your password strength');
    }
    if (twoFactorEnabled < 3) {
      recommendations.push('Enable 2FA on more accounts');
    }
    if (browserSecurityScore < 70) {
      recommendations.push('Review browser security settings');
    }
    if (emailBreached) {
      recommendations.push('Address compromised email accounts');
    }

    return recommendations;
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-gray-700">
      <div className="flex items-center gap-3 mb-6">
        <Award className="w-6 h-6 text-cyan-400" />
        <h2 className="text-xl font-semibold text-white">Security Score</h2>
      </div>

      <div className="space-y-6">
        {/* Overall Score Circle */}
        <div className="flex items-center justify-center">
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="stroke-gray-700"
                strokeWidth="2"
                fill="none"
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className={`${getScoreBg(overallScore).replace('bg-', 'stroke-')} transition-all duration-1000`}
                strokeWidth="2"
                strokeDasharray={`${overallScore}, 100`}
                strokeLinecap="round"
                fill="none"
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className={`text-2xl font-bold ${getScoreColor(overallScore)}`}>
                  {overallScore}
                </div>
                <div className="text-xs text-gray-300">Score</div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h3 className={`text-lg font-semibold ${getScoreColor(overallScore)}`}>
            {getScoreLabel(overallScore)}
          </h3>
          <p className="text-sm text-gray-300">Overall Security Posture</p>
        </div>

        {/* Component Scores */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-black rounded-lg p-3 border border-gray-600">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-blue-400" />
              <span className="text-sm text-gray-200">Password</span>
            </div>
            <div className={`text-lg font-semibold ${getScoreColor(passwordScore)}`}>
              {passwordScore}/100
            </div>
          </div>

          <div className="bg-black rounded-lg p-3 border border-gray-600">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-green-400" />
              <span className="text-sm text-gray-200">2FA Setup</span>
            </div>
            <div className={`text-lg font-semibold ${getScoreColor((twoFactorEnabled / 6) * 100)}`}>
              {twoFactorEnabled}/6
            </div>
          </div>

          <div className="bg-black rounded-lg p-3 border border-gray-600">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-200">Browser</span>
            </div>
            <div className={`text-lg font-semibold ${getScoreColor(browserSecurityScore)}`}>
              {browserSecurityScore}/100
            </div>
          </div>

          <div className="bg-black rounded-lg p-3 border border-gray-600">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-orange-400" />
              <span className="text-sm text-gray-200">Breaches</span>
            </div>
            <div className={`text-lg font-semibold ${emailBreached ? 'text-red-400' : 'text-green-400'}`}>
              {emailBreached ? 'Found' : 'Clean'}
            </div>
          </div>
        </div>

        {/* Recommendations */}
        {getRecommendations().length > 0 && (
          <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-700">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              <h4 className="text-sm font-medium text-blue-400">Recommendations</h4>
            </div>
            <ul className="space-y-1">
              {getRecommendations().map((rec, index) => (
                <li key={index} className="text-sm text-blue-300">• {rec}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Warning for low scores */}
        {overallScore < 60 && (
          <div className="bg-red-900/30 rounded-lg p-4 border border-red-700">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="w-4 h-4 text-red-400" />
              <h4 className="text-sm font-medium text-red-400">Security Alert</h4>
            </div>
            <p className="text-sm text-red-300">
              Your security score is below recommended levels. Please address the highlighted issues to improve your digital security.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}