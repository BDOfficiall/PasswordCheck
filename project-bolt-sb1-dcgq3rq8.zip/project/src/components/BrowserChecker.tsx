import React, { useState } from 'react';
import { Globe, Shield, AlertTriangle, CheckCircle, XCircle, Info } from 'lucide-react';
import { BrowserCheck } from '../types';

export function BrowserChecker() {
  const [checks, setChecks] = useState<BrowserCheck[]>([
    {
      id: 'https',
      name: 'HTTPS Everywhere',
      description: 'Always use secure connections (look for the lock icon)',
      checked: false,
      priority: 'high',
    },
    {
      id: 'extensions',
      name: 'Review Browser Extensions',
      description: 'Remove unused extensions and verify permissions',
      checked: false,
      priority: 'high',
    },
    {
      id: 'updates',
      name: 'Enable Automatic Updates',
      description: 'Keep your browser updated with latest security patches',
      checked: false,
      priority: 'high',
    },
    {
      id: 'passwords',
      name: 'Use Built-in Password Manager',
      description: 'Enable browser password manager or use a dedicated one',
      checked: false,
      priority: 'high',
    },
    {
      id: 'cookies',
      name: 'Block Third-Party Cookies',
      description: 'Prevent cross-site tracking by blocking third-party cookies',
      checked: false,
      priority: 'medium',
    },
    {
      id: 'popups',
      name: 'Block Pop-ups',
      description: 'Enable pop-up blocker to prevent malicious pop-ups',
      checked: false,
      priority: 'medium',
    },
    {
      id: 'downloads',
      name: 'Safe Download Settings',
      description: 'Enable download protection and scan downloaded files',
      checked: false,
      priority: 'medium',
    },
    {
      id: 'location',
      name: 'Control Location Sharing',
      description: 'Review and limit which sites can access your location',
      checked: false,
      priority: 'medium',
    },
    {
      id: 'camera',
      name: 'Control Camera/Microphone',
      description: 'Review permissions for camera and microphone access',
      checked: false,
      priority: 'low',
    },
    {
      id: 'notifications',
      name: 'Manage Notifications',
      description: 'Disable notifications from untrusted websites',
      checked: false,
      priority: 'low',
    },
  ]);

  const toggleCheck = (id: string) => {
    setChecks(checks.map(check => 
      check.id === id ? { ...check, checked: !check.checked } : check
    ));
  };

  const completedChecks = checks.filter(check => check.checked).length;
  const highPriorityCompleted = checks.filter(check => check.priority === 'high' && check.checked).length;
  const highPriorityTotal = checks.filter(check => check.priority === 'high').length;
  
  const overallScore = Math.round((completedChecks / checks.length) * 100);
  const criticalScore = Math.round((highPriorityCompleted / highPriorityTotal) * 100);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertTriangle className="w-4 h-4" />;
      case 'medium': return <Shield className="w-4 h-4" />;
      case 'low': return <Info className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  const browserGuides = [
    {
      name: 'Chrome',
      settings: 'chrome://settings/security',
      icon: '🔴',
    },
    {
      name: 'Firefox',
      settings: 'about:preferences#privacy',
      icon: '🦊',
    },
    {
      name: 'Safari',
      settings: 'Safari → Preferences → Privacy',
      icon: '🧭',
    },
    {
      name: 'Edge',
      settings: 'edge://settings/privacy',
      icon: '🔷',
    },
  ];

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-gray-700">
      <div className="flex items-center gap-3 mb-6">
        <Globe className="w-6 h-6 text-purple-400" />
        <h2 className="text-xl font-semibold text-white">Browser Security Checklist</h2>
      </div>

      <div className="space-y-6">
        {/* Security Score Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-black rounded-lg p-4 border border-gray-600">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-200">Overall Security</span>
              <span className={`text-sm font-medium ${
                overallScore >= 80 ? 'text-green-400' :
                overallScore >= 60 ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {overallScore}%
              </span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-500 ${
                  overallScore >= 80 ? 'bg-green-500' :
                  overallScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${overallScore}%` }}
              />
            </div>
          </div>

          <div className="bg-black rounded-lg p-4 border border-gray-600">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-200">Critical Items</span>
              <span className={`text-sm font-medium ${
                criticalScore >= 80 ? 'text-green-400' :
                criticalScore >= 60 ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {highPriorityCompleted}/{highPriorityTotal}
              </span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-500 ${
                  criticalScore >= 80 ? 'bg-green-500' :
                  criticalScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${criticalScore}%` }}
              />
            </div>
          </div>
        </div>

        {/* Security Checklist */}
        <div className="space-y-3">
          {['high', 'medium', 'low'].map(priority => (
            <div key={priority}>
              <h3 className={`text-sm font-medium mb-3 flex items-center gap-2 ${getPriorityColor(priority)}`}>
                {getPriorityIcon(priority)}
                {priority.charAt(0).toUpperCase() + priority.slice(1)} Priority
              </h3>
              <div className="space-y-2 ml-6">
                {checks
                  .filter(check => check.priority === priority)
                  .map((check) => (
                    <div
                      key={check.id}
                      className={`flex items-start gap-3 p-3 rounded-lg border transition-all cursor-pointer hover:bg-gray-800/50 ${
                        check.checked 
                          ? 'bg-green-900/20 border-green-700' 
                          : 'bg-black border-gray-600'
                      }`}
                      onClick={() => toggleCheck(check.id)}
                    >
                      <div className="mt-0.5">
                        {check.checked ? (
                          <CheckCircle className="w-5 h-5 text-green-400" />
                        ) : (
                          <XCircle className="w-5 h-5 text-gray-500" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-medium ${check.checked ? 'text-green-400' : 'text-white'}`}>
                          {check.name}
                        </h4>
                        <p className="text-sm text-gray-300 mt-1">{check.description}</p>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>

        {/* Browser Settings Quick Access */}
        <div className="bg-black rounded-lg p-4 border border-gray-600">
          <h4 className="text-sm font-medium text-white mb-3">Quick Access to Browser Security Settings</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {browserGuides.map((browser) => (
              <div key={browser.name} className="flex items-center gap-3 p-2 rounded bg-gray-800">
                <span className="text-lg">{browser.icon}</span>
                <div>
                  <p className="text-sm font-medium text-gray-200">{browser.name}</p>
                  <p className="text-xs text-gray-400 font-mono">{browser.settings}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Extensions Recommendation */}
        <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-700">
          <h4 className="text-sm font-medium text-blue-400 mb-2">Recommended Security Extensions</h4>
          <div className="space-y-2 text-sm text-blue-300">
            <p>• <strong>uBlock Origin</strong> - Advanced ad and tracker blocker</p>
            <p>• <strong>HTTPS Everywhere</strong> - Forces secure connections</p>
            <p>• <strong>Privacy Badger</strong> - Blocks trackers automatically</p>
          </div>
        </div>
      </div>
    </div>
  );
}