import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, Shield, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { analyzePassword } from '../utils/passwordStrength';
import { HIBPService } from '../services/hibpService';
import { PasswordStrength } from '../types';

export function PasswordChecker() {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [strength, setStrength] = useState<PasswordStrength | null>(null);
  const [pwnedCount, setPwnedCount] = useState<number | null>(null);
  const [checkingPwned, setCheckingPwned] = useState(false);

  useEffect(() => {
    if (password) {
      const analysis = analyzePassword(password);
      setStrength(analysis);
      
      // Debounce the pwned password check
      const timer = setTimeout(async () => {
        if (password.length > 0) {
          setCheckingPwned(true);
          const count = await HIBPService.checkPasswordPwned(password);
          setPwnedCount(count);
          setCheckingPwned(false);
        }
      }, 500);

      return () => clearTimeout(timer);
    } else {
      setStrength(null);
      setPwnedCount(null);
    }
  }, [password]);

  const getStrengthColor = (score: number) => {
    if (score < 40) return 'bg-red-500';
    if (score < 70) return 'bg-yellow-500';
    if (score < 90) return 'bg-blue-500';
    return 'bg-green-500';
  };

  const getStrengthText = (score: number) => {
    if (score < 40) return 'Weak';
    if (score < 70) return 'Fair';
    if (score < 90) return 'Strong';
    return 'Excellent';
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-gray-700">
      <div className="flex items-center gap-3 mb-6">
        <Shield className="w-6 h-6 text-blue-400" />
        <h2 className="text-xl font-semibold text-white">Password Strength Checker</h2>
      </div>

      <div className="space-y-6">
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password to check its strength..."
            className="w-full bg-black border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors pr-12"
          />
          <button
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
          >
            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        </div>

        {strength && (
          <div className="space-y-4">
            {/* Strength Bar */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-200">Password Strength</span>
                <span className={`text-sm font-medium ${
                  strength.score < 40 ? 'text-red-400' :
                  strength.score < 70 ? 'text-yellow-400' :
                  strength.score < 90 ? 'text-blue-400' : 'text-green-400'
                }`}>
                  {getStrengthText(strength.score)} ({strength.score}/100)
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-500 ${getStrengthColor(strength.score)}`}
                  style={{ width: `${strength.score}%` }}
                />
              </div>
            </div>

            {/* Requirements Checklist */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                { check: strength.isLongEnough, text: 'At least 12 characters' },
                { check: strength.hasUppercase, text: 'Uppercase letters' },
                { check: strength.hasLowercase, text: 'Lowercase letters' },
                { check: strength.hasNumber, text: 'Numbers' },
                { check: strength.hasSpecialChar, text: 'Special characters' },
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  {item.check ? (
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-400" />
                  )}
                  <span className={`text-sm ${item.check ? 'text-green-400' : 'text-red-400'}`}>
                    {item.text}
                  </span>
                </div>
              ))}
            </div>

            {/* Pwned Password Check */}
            <div className="bg-black rounded-lg p-4 border border-gray-600">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-yellow-400" />
                <span className="text-sm font-medium text-white">Data Breach Check</span>
              </div>
              {checkingPwned ? (
                <p className="text-sm text-gray-300">Checking against known breaches...</p>
              ) : pwnedCount !== null ? (
                pwnedCount > 0 ? (
                  <p className="text-sm text-red-400">
                    ⚠️ This password has been found in {pwnedCount.toLocaleString()} data breaches. Use a different password.
                  </p>
                ) : (
                  <p className="text-sm text-green-400">
                    ✅ This password hasn't been found in known data breaches.
                  </p>
                )
              ) : null}
            </div>

            {/* Suggestions */}
            {strength.suggestions.length > 0 && (
              <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-700">
                <h4 className="text-sm font-medium text-blue-400 mb-2">Suggestions for improvement:</h4>
                <ul className="space-y-1">
                  {strength.suggestions.map((suggestion, index) => (
                    <li key={index} className="text-sm text-blue-300">• {suggestion}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        <div className="text-xs text-gray-400 bg-black rounded-lg p-3 border border-gray-700">
          🔒 Your password is never stored or transmitted. All checks are performed locally in your browser.
        </div>
      </div>
    </div>
  );
}