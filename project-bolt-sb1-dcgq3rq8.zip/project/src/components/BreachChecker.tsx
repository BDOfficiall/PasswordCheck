import React, { useState } from 'react';
import { Mail, Search, AlertTriangle, CheckCircle, Clock, ExternalLink } from 'lucide-react';
import { HIBPService } from '../services/hibpService';
import { BreachResult } from '../types';

export function BreachChecker() {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<BreachResult | null>(null);
  const [loading, setLoading] = useState(false);

  const checkBreaches = async () => {
    if (!email || !email.includes('@')) return;
    
    setLoading(true);
    try {
      const breachResult = await HIBPService.checkBreaches(email);
      setResult(breachResult);
    } catch (error) {
      setResult({
        isBreached: false,
        breachCount: 0,
        breaches: [],
        loading: false,
        error: 'Failed to check breaches. Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    checkBreaches();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-gray-700">
      <div className="flex items-center gap-3 mb-6">
        <Mail className="w-6 h-6 text-orange-400" />
        <h2 className="text-xl font-semibold text-white">Email Breach Check</h2>
      </div>

      <div className="space-y-6">
        <form onSubmit={handleSubmit} className="flex gap-3">
          <div className="flex-1">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address..."
              className="w-full bg-black border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-orange-500 transition-colors"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading || !email}
            className="bg-orange-600 hover:bg-orange-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2"
          >
            {loading ? (
              <Clock className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            Check
          </button>
        </form>

        {result && (
          <div className="space-y-4">
            {/* Summary */}
            <div className={`rounded-lg p-4 border ${
              result.error ? 'bg-red-900/30 border-red-700' :
              result.isBreached ? 'bg-red-900/30 border-red-700' : 'bg-green-900/30 border-green-700'
            }`}>
              <div className="flex items-center gap-3">
                {result.error ? (
                  <AlertTriangle className="w-6 h-6 text-red-400" />
                ) : result.isBreached ? (
                  <AlertTriangle className="w-6 h-6 text-red-400" />
                ) : (
                  <CheckCircle className="w-6 h-6 text-green-400" />
                )}
                <div>
                  <h3 className={`font-semibold ${
                    result.error ? 'text-red-400' :
                    result.isBreached ? 'text-red-400' : 'text-green-400'
                  }`}>
                    {result.error ? 'Error Checking Breaches' :
                     result.isBreached ? `Found in ${result.breachCount} Data Breach${result.breachCount !== 1 ? 'es' : ''}` :
                     'No Breaches Found'}
                  </h3>
                  <p className={`text-sm ${
                    result.error ? 'text-red-300' :
                    result.isBreached ? 'text-red-300' : 'text-green-300'
                  }`}>
                    {result.error ? result.error :
                     result.isBreached ? 'Your email was found in known data breaches. Take action immediately.' :
                     'Great! Your email hasn\'t been found in any known data breaches.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Breach Details */}
            {result.isBreached && result.breaches.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-lg font-medium text-white">Breach Details</h4>
                {result.breaches.map((breach, index) => (
                  <div key={index} className="bg-black rounded-lg p-4 border border-gray-600">
                    <div className="flex justify-between items-start mb-2">
                      <h5 className="font-semibold text-white">{breach.Title}</h5>
                      <span className="text-xs text-gray-300">
                        {formatDate(breach.BreachDate)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-200 mb-3" 
                       dangerouslySetInnerHTML={{ __html: breach.Description }} />
                    
                    <div className="space-y-2">
                      <div>
                        <span className="text-xs text-gray-300">Compromised Data:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {breach.DataClasses.map((dataClass, idx) => (
                            <span key={idx} className="text-xs bg-red-900/50 text-red-300 px-2 py-1 rounded">
                              {dataClass}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-xs text-gray-300">
                        <span>Affected Accounts: {breach.PwnCount.toLocaleString()}</span>
                        {breach.IsVerified && (
                          <span className="text-green-400">✓ Verified</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Action Items */}
            {result.isBreached && (
              <div className="bg-yellow-900/30 rounded-lg p-4 border border-yellow-700">
                <h4 className="text-sm font-medium text-yellow-400 mb-2">Immediate Actions Required</h4>
                <ul className="space-y-1 text-sm text-yellow-300">
                  <li>• Change your password immediately</li>
                  <li>• Enable two-factor authentication if not already active</li>
                  <li>• Check for suspicious account activity</li>
                  <li>• Monitor your accounts for unauthorized access</li>
                  <li>• Consider using a password manager</li>
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Info Box */}
        <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-700">
          <div className="flex items-start gap-3">
            <ExternalLink className="w-5 h-5 text-blue-400 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-blue-400 mb-1">About This Check</h4>
              <p className="text-sm text-blue-300">
                This tool uses the HaveIBeenPwned API to check if your email has been compromised in known data breaches. 
                Your email is not stored and the check is performed securely.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}