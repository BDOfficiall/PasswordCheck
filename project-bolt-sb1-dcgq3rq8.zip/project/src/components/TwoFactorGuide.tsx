import React, { useState } from 'react';
import { Smartphone, Key, Shield, CheckCircle, ExternalLink, QrCode } from 'lucide-react';

interface TwoFactorStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

export function TwoFactorGuide() {
  const [steps, setSteps] = useState<TwoFactorStep[]>([
    {
      id: 'authenticator',
      title: 'Install an Authenticator App',
      description: 'Download Google Authenticator, Authy, or Microsoft Authenticator on your phone',
      completed: false,
    },
    {
      id: 'email',
      title: 'Enable 2FA for Email',
      description: 'Secure your primary email account (Gmail, Outlook, etc.) with 2FA',
      completed: false,
    },
    {
      id: 'banking',
      title: 'Enable 2FA for Banking',
      description: 'Add two-factor authentication to all your banking and financial accounts',
      completed: false,
    },
    {
      id: 'social',
      title: 'Enable 2FA for Social Media',
      description: 'Protect your social media accounts (Facebook, Twitter, Instagram, etc.)',
      completed: false,
    },
    {
      id: 'work',
      title: 'Enable 2FA for Work Accounts',
      description: 'Secure your work email, cloud storage, and other professional accounts',
      completed: false,
    },
    {
      id: 'backup',
      title: 'Set Up Backup Codes',
      description: 'Save backup recovery codes in a secure location',
      completed: false,
    },
  ]);

  const toggleStep = (id: string) => {
    setSteps(steps.map(step => 
      step.id === id ? { ...step, completed: !step.completed } : step
    ));
  };

  const completedSteps = steps.filter(step => step.completed).length;
  const progressPercentage = (completedSteps / steps.length) * 100;

  const popularServices = [
    { name: 'Gmail', url: 'https://myaccount.google.com/security', logo: '📧' },
    { name: 'Facebook', url: 'https://facebook.com/settings?tab=security', logo: '📘' },
    { name: 'Twitter', url: 'https://twitter.com/settings/account', logo: '🐦' },
    { name: 'Microsoft', url: 'https://account.microsoft.com/security', logo: '🪟' },
    { name: 'Apple ID', url: 'https://appleid.apple.com/account/manage', logo: '🍎' },
    { name: 'Amazon', url: 'https://amazon.com/a/settings/approval', logo: '📦' },
  ];

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-gray-700">
      <div className="flex items-center gap-3 mb-6">
        <Key className="w-6 h-6 text-green-400" />
        <h2 className="text-xl font-semibold text-white">Two-Factor Authentication Setup</h2>
      </div>

      <div className="space-y-6">
        {/* Progress Overview */}
        <div className="bg-black rounded-lg p-4 border border-gray-600">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-200">Setup Progress</span>
            <span className="text-sm font-medium text-green-400">
              {completedSteps}/{steps.length} completed
            </span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div
              className="h-2 bg-green-500 rounded-full transition-all duration-500"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
        </div>

        {/* Setup Steps */}
        <div className="space-y-3">
          <h3 className="text-lg font-medium text-white mb-4">Setup Checklist</h3>
          {steps.map((step) => (
            <div
              key={step.id}
              className={`flex items-start gap-3 p-4 rounded-lg border transition-all cursor-pointer hover:bg-gray-800/50 ${
                step.completed 
                  ? 'bg-green-900/20 border-green-700' 
                  : 'bg-black border-gray-600'
              }`}
              onClick={() => toggleStep(step.id)}
            >
              <div className="mt-0.5">
                {step.completed ? (
                  <CheckCircle className="w-5 h-5 text-green-400" />
                ) : (
                  <div className="w-5 h-5 rounded-full border-2 border-gray-500" />
                )}
              </div>
              <div className="flex-1">
                <h4 className={`font-medium ${step.completed ? 'text-green-400' : 'text-white'}`}>
                  {step.title}
                </h4>
                <p className="text-sm text-gray-300 mt-1">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Links */}
        <div className="bg-black rounded-lg p-4 border border-gray-600">
          <h4 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
            <ExternalLink className="w-4 h-4" />
            Quick Setup Links for Popular Services
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {popularServices.map((service) => (
              <a
                key={service.name}
                href={service.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2 rounded bg-gray-800 hover:bg-gray-700 transition-colors"
              >
                <span className="text-lg">{service.logo}</span>
                <span className="text-sm text-gray-200">{service.name}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Authenticator App Recommendations */}
        <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-700">
          <h4 className="text-sm font-medium text-blue-400 mb-3 flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            Recommended Authenticator Apps
          </h4>
          <div className="space-y-2">
            {[
              { name: 'Google Authenticator', desc: 'Simple and reliable' },
              { name: 'Authy', desc: 'Cloud backup and multi-device sync' },
              { name: 'Microsoft Authenticator', desc: 'Passwordless authentication support' },
            ].map((app) => (
              <div key={app.name} className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-blue-300">{app.name}</p>
                  <p className="text-xs text-blue-400">{app.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Tip */}
        <div className="bg-yellow-900/30 rounded-lg p-4 border border-yellow-700">
          <div className="flex items-start gap-3">
            <QrCode className="w-5 h-5 text-yellow-400 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-yellow-400 mb-1">Pro Tip</h4>
              <p className="text-sm text-yellow-300">
                Always save your backup codes in a secure location separate from your authenticator app. 
                Consider using a password manager or printing them and storing them safely.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}