const HIBP_API_BASE = 'https://haveibeenpwned.com/api/v3';

export class HIBPService {
  private static async makeRequest(endpoint: string): Promise<any> {
    const response = await fetch(`${HIBP_API_BASE}${endpoint}`, {
      headers: {
        'User-Agent': 'Cyber-Hygiene-Tool',
      },
    });

    if (response.status === 404) {
      return null; // No breaches found
    }

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status}`);
    }

    return response.json();
  }

  static async checkBreaches(email: string) {
    try {
      const breaches = await this.makeRequest(`/breachedaccount/${encodeURIComponent(email)}?truncateResponse=false`);
      return {
        isBreached: breaches !== null,
        breachCount: breaches ? breaches.length : 0,
        breaches: breaches || [],
        loading: false,
        error: null,
      };
    } catch (error) {
      return {
        isBreached: false,
        breachCount: 0,
        breaches: [],
        loading: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }
  }

  static async checkPasswordPwned(password: string): Promise<number> {
    // Create SHA-1 hash
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
    
    const prefix = hashHex.substring(0, 5);
    const suffix = hashHex.substring(5);

    try {
      const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
      const text = await response.text();
      
      const lines = text.split('\n');
      const found = lines.find(line => line.startsWith(suffix));
      
      return found ? parseInt(found.split(':')[1]) : 0;
    } catch (error) {
      console.error('Error checking password:', error);
      return 0;
    }
  }
}