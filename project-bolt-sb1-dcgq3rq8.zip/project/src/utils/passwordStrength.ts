import { PasswordStrength } from '../types';

export function analyzePassword(password: string): PasswordStrength {
  const checks = {
    hasNumber: /\d/.test(password),
    hasLowercase: /[a-z]/.test(password),
    hasUppercase: /[A-Z]/.test(password),
    hasSpecialChar: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password),
    isLongEnough: password.length >= 12,
  };

  const passedChecks = Object.values(checks).filter(Boolean).length;
  let score = 0;
  const feedback: string[] = [];
  const suggestions: string[] = [];

  // Calculate base score
  if (password.length >= 8) score += 20;
  if (password.length >= 12) score += 20;
  if (password.length >= 16) score += 10;
  
  if (checks.hasLowercase) score += 10;
  if (checks.hasUppercase) score += 10;
  if (checks.hasNumber) score += 10;
  if (checks.hasSpecialChar) score += 20;

  // Bonus for variety
  if (passedChecks >= 4) score += 10;
  if (passedChecks === 5) score += 10;

  // Penalties
  if (password.length < 8) score = Math.min(score, 30);
  if (/(.)\1{2,}/.test(password)) score -= 10; // Repeated characters
  if (/123|abc|qwe|password|admin/i.test(password)) score -= 20; // Common patterns

  score = Math.max(0, Math.min(100, score));

  // Generate feedback
  if (score < 40) {
    feedback.push('Weak password - easily guessable');
  } else if (score < 70) {
    feedback.push('Moderate password - could be stronger');
  } else if (score < 90) {
    feedback.push('Strong password - good security');
  } else {
    feedback.push('Excellent password - very secure');
  }

  // Generate suggestions
  if (!checks.isLongEnough) {
    suggestions.push('Use at least 12 characters for better security');
  }
  if (!checks.hasUppercase) {
    suggestions.push('Add uppercase letters (A-Z)');
  }
  if (!checks.hasLowercase) {
    suggestions.push('Add lowercase letters (a-z)');
  }
  if (!checks.hasNumber) {
    suggestions.push('Add numbers (0-9)');
  }
  if (!checks.hasSpecialChar) {
    suggestions.push('Add special characters (!@#$%^&*)');
  }
  if (/(.)\1{2,}/.test(password)) {
    suggestions.push('Avoid repeating characters');
  }
  if (/123|abc|qwe|password|admin/i.test(password)) {
    suggestions.push('Avoid common words and patterns');
  }

  return {
    score,
    feedback,
    suggestions,
    ...checks,
  };
}