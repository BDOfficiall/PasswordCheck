export interface PasswordStrength {
  score: number;
  feedback: string[];
  suggestions: string[];
  hasNumber: boolean;
  hasLowercase: boolean;
  hasUppercase: boolean;
  hasSpecialChar: boolean;
  isLongEnough: boolean;
}

export interface BreachResult {
  isBreached: boolean;
  breachCount: number;
  breaches: Breach[];
  loading: boolean;
  error: string | null;
}

export interface Breach {
  Name: string;
  Title: string;
  Domain: string;
  BreachDate: string;
  AddedDate: string;
  ModifiedDate: string;
  PwnCount: number;
  Description: string;
  LogoPath: string;
  DataClasses: string[];
  IsVerified: boolean;
  IsFabricated: boolean;
  IsSensitive: boolean;
  IsRetired: boolean;
  IsSpamList: boolean;
}

export interface BrowserCheck {
  id: string;
  name: string;
  description: string;
  checked: boolean;
  priority: 'high' | 'medium' | 'low';
}