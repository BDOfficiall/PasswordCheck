import React, { useState, useEffect } from 'react';
import { Shield, Lock, Globe, Mail, BarChart3 } from 'lucide-react';
import { PasswordChecker } from './components/PasswordChecker';
import { TwoFactorGuide } from './components/TwoFactorGuide';
import { BrowserChecker } from './components/BrowserChecker';
import { BreachChecker } from './components/BreachChecker';
import { SecurityScore } from './components/SecurityScore';

type TabType = 'overview' | 'password' | '2fa' | 'browser' | 'breach';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [securityData, setSecurityData] = useState({
    passwordScore: 0,
    twoFactorEnabled: 0,
    browserSecurityScore: 0,
    emailBreached: false,
  });

  const tabs = [
    { id: 'overview' as TabType, name: 'Overview', icon: BarChart3, color: 'text-cyan-400' },
    { id: 'password' as TabType, name: 'Password', icon: Lock, color: 'text-blue-400' },
    { id: '2fa' as TabType, name: '2FA Setup', icon: Shield, color: 'text-green-400' },
    { id: 'browser' as TabType, name: 'Browser', icon: Globe, color: 'text-purple-400' },
    { id: 'breach' as TabType, name: 'Breach Check', icon: Mail, color: 'text-orange-400' },
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Cyber Protector</h1>
                <p className="text-xs text-gray-300">Security Self-Assessment Tool</p>
              </div>
            </div>
            <div className="hidden md:block text-sm text-gray-300">
              Protect Your Digital Life
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-gray-900/30 backdrop-blur-sm border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto py-4">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? `bg-gray-700 ${tab.color} shadow-lg`
                      : 'text-gray-300 hover:text-white hover:bg-gray-700/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.name}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">
                How Secure Are You?
              </h2>
              <p className="text-lg text-gray-300 max-w-2xl mx-auto">
                Get a comprehensive view of your digital security posture. Check your passwords, 
                enable two-factor authentication, secure your browser, and monitor for data breaches.
              </p>
            </div>
            
            <SecurityScore
              passwordScore={securityData.passwordScore}
              twoFactorEnabled={securityData.twoFactorEnabled}
              browserSecurityScore={securityData.browserSecurityScore}
              emailBreached={securityData.emailBreached}
            />

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {tabs.slice(1).map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className="bg-gray-900 hover:bg-gray-800 border border-gray-700 rounded-xl p-6 text-left transition-all hover:border-gray-600 group"
                  >
                    <div className={`${tab.color} mb-3 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-8 h-8" />
                    </div>
                    <h3 className="text-white font-semibold mb-2">{tab.name}</h3>
                    <p className="text-sm text-gray-300">
                      {tab.id === 'password' && 'Check your password strength'}
                      {tab.id === '2fa' && 'Set up two-factor authentication'}
                      {tab.id === 'browser' && 'Review browser security settings'}
                      {tab.id === 'breach' && 'Check for data breaches'}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'password' && <PasswordChecker />}
        {activeTab === '2fa' && <TwoFactorGuide />}
        {activeTab === 'browser' && <BrowserChecker />}
        {activeTab === 'breach' && <BreachChecker />}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900/50 border-t border-gray-700 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-300 text-sm mb-2">
              🔒 Your privacy is protected - all checks are performed securely and no data is stored.
            </p>
            <p className="text-gray-400 text-xs">
              Powered by HaveIBeenPwned API • Built with security in mind
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;